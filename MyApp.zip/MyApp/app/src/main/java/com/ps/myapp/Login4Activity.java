package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login4Activity extends AppCompatActivity {
    Button mbtnGoogle,mbtnFacebook,mbtnLogin;
    EditText metEmail,metPassword;
    TextView mtvRegister;
    Context mContext;
    private String TAG = "Login4Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login4);
        initValues();
        clickEvents();
    }

    private void clickEvents() {
        mbtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
        mbtnGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent google=new Intent(Intent.ACTION_VIEW);
                google.setData(Uri.parse("https://accounts.google.com/signin/v2/identifier?flowName=GlifWebSignIn&flowEntry=ServiceLogin"));
                startActivity(google);

            }
        });
        mbtnFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent facebook =new Intent(Intent.ACTION_VIEW);
                facebook.setData(Uri.parse("https://www.facebook.com/"));
                startActivity(facebook);
            }
        });
        mtvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent register = new Intent(mContext,Registration4Activity.class);
                startActivity(register);

            }
        });


    }

    private void checkValidation() {
        if(metEmail.getText().toString().trim().length() < 1){
            Toast.makeText(mContext,"Enter your email",Toast.LENGTH_SHORT).show();
        }
        else if(metEmail.getText().toString().trim().length() <1){
            Toast.makeText(mContext,"Enter your password",Toast.LENGTH_SHORT).show();
        }
        else{
            Intent login = new Intent(mContext,Dashboard4Activity.class);
            startActivity(login);
            finish();
        }
    }

    private void initValues() {
        mContext = this;
        metEmail = findViewById(R.id.etEmail);
        metPassword = findViewById(R.id.etPassword);
        mtvRegister = findViewById(R.id.tvRegister);
        mbtnLogin = findViewById(R.id.btnLogin);
        mbtnGoogle = findViewById(R.id.btnGoogle);
        mbtnFacebook = findViewById(R.id.btnFacebook);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}