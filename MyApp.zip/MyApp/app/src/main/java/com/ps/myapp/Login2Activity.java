package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login2Activity extends AppCompatActivity {
    EditText metName, metPassword;
    Button mbtnLogin;/*, mbtnRegister;*/
    Context mContext;
    private String TAG = "Login2Activity";
    TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        initValues();
        clickEvents();
    }

    private void clickEvents() {
        mbtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, Registration2Activity.class);
                startActivity(intent);
            }
        });
    }

    private void checkValidation() {
        if (metName.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Your Name", Toast.LENGTH_SHORT).show();
        } else if (metPassword.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Your Password", Toast.LENGTH_SHORT).show();
        } else {
//            Intent intent = new Intent(mContext,MainActivity.class);
//            startActivity(intent);
            finish();
        }
    }

    private void initValues() {
        mContext = this;
        metName = findViewById(R.id.etName);
        metPassword = findViewById(R.id.etPassword);
        mbtnLogin = findViewById(R.id.btnLogin);
//        mbtnRegister = findViewById(R.id.btnRegister);
        tvRegister = findViewById(R.id.tvRegister);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}