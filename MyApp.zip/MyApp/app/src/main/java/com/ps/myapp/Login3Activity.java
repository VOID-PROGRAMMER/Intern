package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login3Activity extends AppCompatActivity {
    EditText metEmail,metPassword;
    Button mbtnLogin;
    TextView mtvRegister,mtvForgotPass;
    Context mContext;
    private String TAG = "Login3Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login3);
        initValues();
        clickEvents();
    }

    private void clickEvents() {
        mbtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
                finish();
            }
        });
        mtvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent register = new Intent(mContext,Registration3Activity.class);
               startActivity(register);
            }
        });
        mtvForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgotpass = new Intent(mContext,ForgotPass3Activity.class);
                startActivity(forgotpass);
            }
        });
    }

    private void checkValidation() {
        if (metEmail.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Your Name", Toast.LENGTH_SHORT).show();

        }
        else if(metPassword.getText().toString().trim().length() < 1){
            Toast.makeText(mContext, "Enter Your Email", Toast.LENGTH_SHORT).show();
        }
        else{
            Intent login = new Intent(mContext,DashboardActivity.class);
            startActivity(login);
        }
    }

    private void initValues() {
        mContext = this;
        metEmail = findViewById(R.id.etEmail);
        metPassword = findViewById(R.id.etPassword);
        mbtnLogin = findViewById(R.id.btnLogin);
        mtvRegister = findViewById(R.id.tvRegister);
        mtvForgotPass = findViewById(R.id.tvForgotPass);

    }
}


//https://creazilla.com/nodes/1631569-abstract-shape-silhouette