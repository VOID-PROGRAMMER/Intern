package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText mEtName, mEtPassword;
    Button mBtnLogin, mBtnReg;
    CheckBox mCheckRem;
    Context mContext;
    private String TAG = "LoginActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initValues();
        clickEvents();


    }

    private void initValues() {
        mContext = this;
        mEtName = findViewById(R.id.etName);
        mEtPassword = findViewById(R.id.etPassword);
        mCheckRem = findViewById(R.id.checkRemember);
        mBtnLogin = findViewById(R.id.btnLogin);
        mBtnReg = findViewById(R.id.btnRegister);

    }

    private void clickEvents() {

        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /**/
                checkValidation();
            }
        });

        mBtnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(LoginActivity.this, RegistrationActivity.class);
//                startActivity(intent);
                Intent intent = new Intent(mContext, DetailRegistrationActivity.class);
                startActivity(intent);
            }
        });


    }


    private void checkValidation() {
        if (mEtName.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter name", Toast.LENGTH_SHORT).show();
        } else if (mEtPassword.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter password", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);

        }


    }


}