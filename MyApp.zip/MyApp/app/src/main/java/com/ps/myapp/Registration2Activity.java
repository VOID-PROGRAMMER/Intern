package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Registration2Activity extends AppCompatActivity {
    EditText metName, metEmail, metMobile, metPassword, metConfirmPassword;
    Button /*mbtnLogin,*/ mbtnRegister;
    Context mContext;
    private String TAG = "Registration2Activity";
    TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration2);
        initValues();
        clickEvents();
    }

    private void clickEvents() {
        mbtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, Login2Activity.class);
                startActivity(intent);
            }
        });
    }

    private void checkValidation() {
        if (metName.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter your name", Toast.LENGTH_SHORT).show();
        } else if (metEmail.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter your email", Toast.LENGTH_SHORT).show();
        } else if (metMobile.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter your number", Toast.LENGTH_SHORT).show();
        } else if (metPassword.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter your Password", Toast.LENGTH_SHORT).show();
        } else if (metConfirmPassword.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Renter your Password", Toast.LENGTH_SHORT).show();
        } else if (!metConfirmPassword.getText().toString().trim().equals(metPassword.getText().toString().trim())) {
            Toast.makeText(mContext, "Password not matched", Toast.LENGTH_SHORT).show();
        } else {
            finish();
        }
    }

    private void initValues() {
        mContext = this;
        metName = findViewById(R.id.etName);
        metEmail = findViewById(R.id.etEmail);
        metMobile = findViewById(R.id.etMobile);
        metPassword = findViewById(R.id.etPassword);
        metConfirmPassword = findViewById(R.id.etConfirmPassword);
        mbtnRegister = findViewById(R.id.btnRegister);
        tvLogin = findViewById(R.id.tvLogin);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}