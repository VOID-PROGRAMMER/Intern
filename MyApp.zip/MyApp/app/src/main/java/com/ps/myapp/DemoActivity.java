package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DemoActivity extends AppCompatActivity {
    EditText metEmail,metPassword;
    Button mbtnLogin,mbtnGoogle,mbtnFacebook;
    TextView mtvRegister,mtvForgotPass;
    Context mContext;
    private String TAG ="DemoActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);
        initValues();
        clickEvents();
    }
    private void clickEvents() {
        mbtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
                finish();
            }
        });
        mtvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent register = new Intent(mContext,Registration3Activity.class);
                startActivity(register);
            }
        });
        mtvForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgotpass = new Intent(mContext,ForgotPass3Activity.class);
                startActivity(forgotpass);
            }
        });
        mbtnGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent google = new Intent(Intent.ACTION_SEND);
                google.setData(Uri.parse("https://accounts.google.com/signin/v2/identifier?flowName=GlifWebSignIn&flowEntry=ServiceLogin"));
                startActivity(google);
            }
        });
        mbtnFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent google = new Intent(Intent.ACTION_SEND);
                google.setData(Uri.parse("https://m.facebook.com/?locale=en_GB"));
                startActivity(google);
            }
        });
    }

    private void checkValidation() {
        if (metEmail.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Your Name", Toast.LENGTH_SHORT).show();

        }
        else if(metPassword.getText().toString().trim().length() < 1){
            Toast.makeText(mContext, "Enter Your Email", Toast.LENGTH_SHORT).show();
        }
        else{
            Intent login = new Intent(mContext,DashboardActivity.class);
            startActivity(login);
        }
    }

    private void initValues() {
        mContext = this;
        metEmail = findViewById(R.id.etEmail);
        metPassword = findViewById(R.id.etPassword);
        mbtnLogin = findViewById(R.id.btnLogin);
        mbtnGoogle = findViewById(R.id.btnGoogle);
        mbtnFacebook = findViewById(R.id.btnFacebook);
        mtvRegister = findViewById(R.id.tvRegister);
        mtvForgotPass = findViewById(R.id.tvForgotPass);

    }
}