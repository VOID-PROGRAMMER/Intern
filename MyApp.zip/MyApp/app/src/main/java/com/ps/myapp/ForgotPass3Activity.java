package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ForgotPass3Activity extends AppCompatActivity {
    EditText metEmail,metPassword,metConfirmPassword;
    Button mbtnDone;
    Context mContext;
    private String TAG = "ForgotPass3Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pass3);
        initValues();
        clickEvent();
    }

    private void clickEvent() {
        mbtnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
    }

    private void checkValidation() {
        if(metEmail.getText().toString().trim().length() < 1){
            Toast.makeText(mContext,"Enter you email",Toast.LENGTH_SHORT).show();

        }
        else if(metPassword.getText().toString().trim().length() < 1){
            Toast.makeText(mContext,"Enter you Password",Toast.LENGTH_SHORT).show();
        }
        else if(metConfirmPassword.getText().toString().trim().length() < 1){
            Toast.makeText(mContext,"Renter you Password",Toast.LENGTH_SHORT).show();
        }
        else if(!metPassword.getText().toString().trim().equals(metConfirmPassword.getText().toString().trim())){
            Toast.makeText(mContext,"Password Mismatch",Toast.LENGTH_SHORT).show();
        }
        else{
            finish();
        }
    }

    private void initValues() {
        mContext = this;
        metEmail = findViewById(R.id.etEmail);
        metPassword = findViewById(R.id.etPassword);
        metConfirmPassword = findViewById(R.id.etConfirmPassword);
        mbtnDone = findViewById(R.id.btnDone);
    }
}