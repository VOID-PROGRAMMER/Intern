package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Registration4Activity extends AppCompatActivity {
    EditText metName,metAge,metEduSys,metLanguage;
    Button mbtnAddkid,mbtnNext;
    TextView mtvSkip;
    RadioButton mradioFemale,mradioMale;
    Context mContext;
    private String TAG ="Registration4Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration4);
        initValues();
        checkEvents();
    }

    private void checkEvents() {
        mbtnAddkid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();

            }
        });
        mbtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext,Dashboard4Activity.class);
                startActivity(intent);
            }
        });
        mtvSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext,Dashboard4Activity.class);
                startActivity(intent);
            }
        });

    }

    private void checkValidation() {
        if(metName.getText().toString().trim().length() < 1){
            Toast.makeText(mContext,"Enter kid name",Toast.LENGTH_SHORT).show();
        }
        else if(metAge.getText().toString().trim().length() <1){
            Toast.makeText(mContext,"Enter Age",Toast.LENGTH_SHORT).show();
        }
        else if(metEduSys.getText().toString().trim().length() <1){
            Toast.makeText(mContext,"Enter Age",Toast.LENGTH_SHORT).show();
        }
        else if(metLanguage.getText().toString().trim().length() <1){
            Toast.makeText(mContext,"Enter Age",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(mContext,"Added Successfully",Toast.LENGTH_SHORT).show();

        }

    }

    private void initValues() {
        mContext = this;
        metName = findViewById(R.id.etName);
        metAge = findViewById(R.id.etAge);
        metEduSys = findViewById(R.id.etEduSys);
        metLanguage = findViewById(R.id.etLanguage);
        mbtnAddkid = findViewById(R.id.btnAddkid);
        mbtnNext = findViewById(R.id.btnNext);
        mtvSkip = findViewById(R.id.tvSkip);
        mradioFemale = findViewById(R.id.radioFemale);
        mradioMale = findViewById(R.id.radioMale);

    }
}