package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {
    EditText metName, metEmail, metMobile, metAddress, metPassword;
    Button metSubmit;
    Context mContext;
    private String TAG = "RegistrationActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        initValues();
        checkEvents();
    }

    public void initValues() {
        mContext = this;
        metName = findViewById(R.id.etName);
        metEmail = findViewById(R.id.etEmail);
        metMobile = findViewById(R.id.etMobile);
        metAddress = findViewById(R.id.etAddress);
        metPassword = findViewById(R.id.etPassword);
        metSubmit = findViewById(R.id.btnSubmit);


    }

    public void checkEvents() {
        metSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             /*   Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                startActivity(intent);*/
                checkValidation();

            }
        });


    }

    private void checkValidation() {
        if (metName.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter name", Toast.LENGTH_SHORT).show();
        } else if (metEmail.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter email", Toast.LENGTH_SHORT).show();
        } else if (metMobile.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter mobile", Toast.LENGTH_SHORT).show();
        } else if (metAddress.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter address", Toast.LENGTH_SHORT).show();
        } else if (metPassword.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter password", Toast.LENGTH_SHORT).show();
        } else {
           /* Intent intent = new Intent(mContext, LoginActivity.class);
            startActivity(intent);*/
            finish();
        }


    }
}