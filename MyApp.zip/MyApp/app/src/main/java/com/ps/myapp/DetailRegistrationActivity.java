package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class DetailRegistrationActivity extends AppCompatActivity {
    EditText etName, etEmail, etMobile, etDob, etPassword, etConfirmPassword;
    RadioButton radioMale, radioFemale;
    CheckBox checkTerms;
    Button btnRegister, btnLogin;
    Context mContext;
    private String TAG = "DetailRegistrationActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_registration);
        initValues();
        checkEvents();
    }

    public void checkEvents() {
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }

        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void checkValidation() {
        if (etName.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Name", Toast.LENGTH_SHORT).show();
        } else if (etEmail.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Email", Toast.LENGTH_SHORT).show();
        } else if (etMobile.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Number", Toast.LENGTH_SHORT).show();
        } else if (etDob.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Dob", Toast.LENGTH_SHORT).show();
        } else if (etPassword.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Enter Password", Toast.LENGTH_SHORT).show();
        } else if (etConfirmPassword.getText().toString().trim().length() < 1) {
            Toast.makeText(mContext, "Renter Password", Toast.LENGTH_SHORT).show();
        } else if (!etPassword.getText().toString().trim().equals(etConfirmPassword.getText().toString().trim())) {
            Toast.makeText(mContext, "Password not matched", Toast.LENGTH_SHORT).show();
        } else {
            finish();
        }
    }

    private void initValues() {
        mContext = this;
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etMobile = findViewById(R.id.etMobile);
        etDob = findViewById(R.id.etDob);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        radioMale = findViewById(R.id.radioMale);
        radioFemale = findViewById(R.id.radioFemale);
        checkTerms = findViewById(R.id.checkTerms);
        btnRegister = findViewById(R.id.btnRegister);
        btnLogin = findViewById(R.id.btnLogin);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}