package com.ps.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Dashboard4Activity extends AppCompatActivity {
    TextView tvLogout;
    Context mContext;
    private String TAG ="Dashboard4Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard4);
        initValues();
        checkEvent();
    }

    private void checkEvent() {
        tvLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent logout = new Intent(mContext,Login4Activity.class);
                startActivity(logout);
                finish();
            }
        });
    }

    private void initValues() {
        mContext =this;
        tvLogout = findViewById(R.id.tvLogout);

    }
}